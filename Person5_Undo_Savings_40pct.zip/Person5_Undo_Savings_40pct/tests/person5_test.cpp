// Person 5 - Phase 2 unit test (UndoAction + UndoStack, 40% scope)
#include "UndoStack.h"
#include <iostream>

#define CHECK(c) do { if (!(c)) { std::cout << "FAIL line " << __LINE__ << ": " #c "\n"; return 1; } } while (0)

int main() {
    UndoStack s;
    UndoAction out;
    CHECK(s.isEmpty() && s.getSize() == 0 && !s.pop(out) && !s.peek(out));

    UndoAction add(ActionType::ADD, 7);
    UndoAction del(ActionType::DELETE, 9);
    Expense snapshot(9, "01-01-2026", 500, "Shop", "Food", "ONE_TIME", "NONE");
    del.setBeforeSnapshot(snapshot);
    CHECK(s.push(add) && s.push(del) && s.getSize() == 2);

    CHECK(s.peek(out) && out.getType() == ActionType::DELETE && s.getSize() == 2);   // peek keeps it
    CHECK(s.pop(out) && out.getType() == ActionType::DELETE && out.getExpenseId() == 9);
    Expense restored;
    CHECK(out.getBeforeSnapshot(restored) && restored.getId() == 9 && restored.getAmountPaise() == 500);
    CHECK(s.pop(out) && out.getType() == ActionType::ADD && out.getExpenseId() == 7);
    Expense none;
    CHECK(!out.getBeforeSnapshot(none));                  // ADD stores no snapshot
    CHECK(s.isEmpty());                                   // LIFO order confirmed

    int pushed = 0;
    while (s.push(UndoAction(ActionType::ADD, pushed + 1))) ++pushed;
    CHECK(pushed == 100 && s.isFull() && !s.push(add));   // bounded at 100
    s.clear();
    CHECK(s.isEmpty());
    std::cout << "All Person 5 (40% scope) tests passed.\n";
    return 0;
}
