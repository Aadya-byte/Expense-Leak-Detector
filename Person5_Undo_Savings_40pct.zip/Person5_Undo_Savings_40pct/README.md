# Person 5 - Undo Stack (Savings Advisor pending)

**Phase 2 delivery - about 40%% of the planned work.**

**Share of the supplied source delivered:** 50% of the supplied Person 5 source (UndoAction + UndoStack).

## What is done (40%)

- UndoAction: stores action type (ADD / DELETE), expense ID and a snapshot of a deleted record
- UndoStack: hand-made bounded stack on a fixed array (capacity 100): push, pop, peek, isEmpty, isFull, clear, getSize
- Integrated rules: undo of ADD deletes the new record; undo of DELETE restores the saved record with its original ID
- person5_test.cpp: LIFO order, peek, snapshot restore, full / empty behaviour, capacity limit

## What is NOT done yet (remaining 60%)

- SavingsAdvisor: monthly total, month-end forecast, budget comparison, potential savings at a chosen reduction % (menu option 8)
- Undo of EDIT actions (needs Person 1 editExpense)
- Recursion demonstration (recursive linked-list traversal / sum) and suggestion text
- Extended tests

## Folder layout

- `src/` - this member's own files: UndoAction.h, UndoAction.cpp, UndoStack.h, UndoStack.cpp
- `deps/` - files from other members that this module needs to compile (unchanged copies of the team's agreed versions)
- `tests/` - person5_test.cpp
- `API.md` - public functions delivered and pending

- `Makefile` - `make test` compiles and runs this module's test

## Build and test

```sh
make test
```

Expected output: `All Person 5 (40% scope) tests passed.`

## Rules followed

- C++11, no STL containers or algorithms (`vector`, `list`, `map`, `stack`, `sort()` ... are not used).
- Money is stored as integer paise (15000 = Rs. 150.00); dates are DD-MM-YYYY.
- One shared `Expense` / `ExpenseManager` definition (Person 1's); no module keeps a second master list of expenses.
