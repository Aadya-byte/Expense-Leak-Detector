# Person 5 - Undo Stack (Savings Advisor pending) - API of the 40% delivery

## Public interface delivered

- `UndoAction(ActionType type, long long expenseId);  ActionType::ADD / DELETE`
- `void UndoAction::setBeforeSnapshot(const Expense&);  bool getBeforeSnapshot(Expense&) const`
- `bool UndoStack::push(const UndoAction&)  - false when full (100)`
- `bool UndoStack::pop(UndoAction&);  bool peek(UndoAction&) const`
- `bool isEmpty() const;  bool isFull() const;  void clear();  int getSize() const`

## Still pending (Phase 3)

- SavingsAdvisor: monthly total, month-end forecast, budget comparison, potential savings at a chosen reduction % (menu option 8)
- Undo of EDIT actions (needs Person 1 editExpense)
- Recursion demonstration (recursive linked-list traversal / sum) and suggestion text
- Extended tests
