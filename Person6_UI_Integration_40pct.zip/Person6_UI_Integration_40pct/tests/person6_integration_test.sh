#!/bin/sh
# Person 6 - Phase 2 integration test: runs the real application end to end
# (add -> view -> sort -> search -> leak report -> delete -> undo -> save -> restart).
# Usage: tests/person6_integration_test.sh <path-to-expense_leak_detector>
APP=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
WORK=$(mktemp -d); cd "$WORK" || exit 1
fail=0
check() { if echo "$OUT" | grep -q -- "$2"; then echo "[PASS] $1"; else echo "[FAIL] $1"; fail=1; fi; }

OUT=$(printf '%s\n' \
  1 16-10-2026 12550 "Cafe Aroma" Food ONE_TIME NONE \
  1 17-10-2026 9900  "Cafe Aroma" Food ONE_TIME NONE \
  1 18-10-2026 7500  "Cafe Aroma" Food ONE_TIME NONE \
  1 15-10-2026 49900 StreamBox Subscription RECURRING MONTHLY \
  1 31-02-2026 100 Bad Food ONE_TIME NONE \
  1 14-10-2026 100 Bad Food ONE_TIME MONTHLY \
  2  6 2  6 3  5 1 2  5 2 2  7  4 2  2 9  2 3 8 10 abc 99 11 | "$APP")
check "starts with no saved data"            "No saved data found"
check "adds four valid expenses"             "Assigned ID: 4"
check "rejects invalid calendar date"        "expense was not added"
check "view lists records"                   "Merchant: StreamBox"
check "sort by amount works"                 "Rs. 499.00"
check "linear search finds record"           "Found: ID: 1 "
check "binary search finds record"           "Found: ID: 2 "
check "leak report detects Food:Cafe Aroma"  "Food:Cafe Aroma"
check "leak report flags frequent spending"  "FREQUENT SPENDING"
check "delete works"                         "Expense deleted successfully"
check "undo restores deleted record"         "Undo completed"
check "pending features are announced"       "is pending"
check "invalid menu input handled"           "Invalid input"
check "saves on exit"                        "Goodbye"

OUT=$(printf '%s\n' 2 11 | "$APP")
check "restart reloads saved expenses"       "Loaded 4 saved expense"
check "restart shows persisted data"         "Merchant: Cafe Aroma"

printf '1|16-10-2026|100|Ok|Food|ONE_TIME|NONE\nGARBAGE\n' > data/expenses.txt
OUT=$(printf '%s\n' 2 11 | "$APP")
check "corrupt line is skipped, app survives" "malformed/duplicate line"

OUT=$(printf '2\n' | "$APP")
check "closed input does not hang"           "Goodbye"
cd / && rm -rf "$WORK"
[ $fail -eq 0 ] && echo "All Person 6 integration checks passed." || echo "SOME CHECKS FAILED"
exit $fail
