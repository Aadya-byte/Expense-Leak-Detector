# Person 6 - UI, Integration & Testing

**Phase 2 delivery - about 40%% of the planned work.**

**Share of the supplied source delivered:** 71% of the supplied Person 6 source (the integration hub must touch every module).

## What is done (40%)

- main.cpp: single entry point - loads data/expenses.txt, runs the UI, saves on exit
- UI: 11-option console menu; validated input helpers (numbers, amounts, text, closed input); Add, View, Delete, Search (linear/binary), Sort (ID/amount/date), Leak report, Undo wired to the real modules
- Features that belong to the pending 60% print a clear "[PENDING - Phase 3]" notice instead of crashing
- Makefile (build + all tests), demo dataset data/expenses.txt, integration script with 18 end-to-end checks (add, invalid date, sort, search, leak report, delete, undo, save, restart, corrupt file, closed input)
- Fixed an infinite loop on closed input (EOF) found during integration

## What is NOT done yet (remaining 60%)

- Menu actions for Edit, Forecast & savings, Export report (waiting for the pending modules)
- Dashboard, formatted tables, category/merchant filters
- Full-application integration tests, screenshots and final demo script
- Final README / INTEGRATION_CHECKLIST update after Phase 3

## Folder layout

- `src/` - this member's own files: UI.h, UI.cpp, main.cpp
- `deps/` - files from other members that this module needs to compile (unchanged copies of the team's agreed versions)
- `tests/` - person6_integration_test.sh
- `API.md` - public functions delivered and pending

- `data/expenses.txt` - demo dataset (8 records, loaded automatically at start)
- `Makefile` - `make` builds the application, `make test` runs every check

## Build, test and run

```sh
make            # builds ./expense_leak_detector
make test       # runs the 18-check integration script
./expense_leak_detector
```

Expected test output ends with: `All Person 6 integration checks passed.`

## Rules followed

- C++11, no STL containers or algorithms (`vector`, `list`, `map`, `stack`, `sort()` ... are not used).
- Money is stored as integer paise (15000 = Rs. 150.00); dates are DD-MM-YYYY.
- One shared `Expense` / `ExpenseManager` definition (Person 1's); no module keeps a second master list of expenses.
