#ifndef RECORD_PARSER_H
#define RECORD_PARSER_H

/*
 * ============================================================================
 * RECORD PARSER MODULE (Person 2) -- Phase 2 (40%)
 * - Parses one pipe-delimited line into a validated Expense (Person 1 class).
 * - Validates all seven fields: ID | Date | Amount | Merchant | Category |
 *   Type | Frequency, incl. calendar dates and type/frequency consistency.
 * - Rejects lines with a misplaced '|' or malformed values.
 * - Zero STL containers.
 *
 * PENDING (Phase 3): decimal-rupee amounts ("150.50"), YEARLY frequency,
 *   independent calendar validation inside the parser.
 * ============================================================================
 */

class Expense;

class RecordParser {
public:
    RecordParser();
    ~RecordParser();

    // Returns true and fills outputExpense on success; false if malformed.
    bool parseRecord(const char* line, Expense& outputExpense) const;

    // Validates every field of an already constructed Expense.
    bool validateRecord(const Expense& expense) const;

private:
    bool parseAmount(const char* amountStr, long long& outPaise) const;
    bool parsePositiveInt(const char* str, int& outVal) const;
    bool isValidType(const char* typeStr) const;
    bool isValidFrequency(const char* freqStr, const char* typeStr) const;
    static void trimWhitespace(char* str);
    static bool isAllWhitespace(const char* str);
};

#endif // RECORD_PARSER_H
