#include "UndoAction.h"

UndoAction::UndoAction()
    : type(ActionType::UNKNOWN), expenseId(-1), hasBefore(false) {}

UndoAction::UndoAction(ActionType t, long long id)
    : type(t), expenseId(id), hasBefore(false) {}

ActionType UndoAction::getType() const { return type; }
long long UndoAction::getExpenseId() const { return expenseId; }

bool UndoAction::getBeforeSnapshot(Expense& outExpense) const {
    if (!hasBefore) return false;
    outExpense = beforeSnapshot;
    return true;
}

void UndoAction::setBeforeSnapshot(const Expense& expense) {
    beforeSnapshot = expense;
    hasBefore = true;
}
