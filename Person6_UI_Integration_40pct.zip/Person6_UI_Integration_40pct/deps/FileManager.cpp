/*
 * FILE MANAGER MODULE IMPLEMENTATION (Person 2) -- Phase 2 (40%)
 */

#include "FileManager.h"
#include "ExpenseManager.h"
#include "RecordParser.h"
#include "Expense.h"

#include <fstream>
#include <cstdio>
#include <cstring>

#if defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
#include <direct.h>
#define MKDIR(dir) _mkdir(dir)
#else
#include <sys/stat.h>
#define MKDIR(dir) mkdir(dir, 0755)
#endif

FileManager::FileManager(const char* filePath) : m_loadedCount(0), m_skippedCount(0) {
    m_lastError[0] = '\0';
    setFilePath(filePath);
}

FileManager::~FileManager() {}

const char* FileManager::getLastError() const { return m_lastError; }
const char* FileManager::getFilePath() const { return m_filePath; }
int FileManager::getLoadedCount() const { return m_loadedCount; }
int FileManager::getSkippedCount() const { return m_skippedCount; }

void FileManager::setFilePath(const char* filePath) {
    const char* chosen = (filePath != NULL && *filePath != '\0') ? filePath : "data/expenses.txt";
    std::strncpy(m_filePath, chosen, sizeof(m_filePath) - 1);
    m_filePath[sizeof(m_filePath) - 1] = '\0';
}

void FileManager::setLastError(const char* error) {
    if (error != NULL) {
        std::strncpy(m_lastError, error, sizeof(m_lastError) - 1);
        m_lastError[sizeof(m_lastError) - 1] = '\0';
    } else {
        m_lastError[0] = '\0';
    }
}

bool FileManager::ensureParentDirectoryExists(const char* filePath) {
    if (filePath == NULL) return false;

    const char* lastSlash = NULL;
    for (const char* p = filePath; *p != '\0'; ++p) {
        if (*p == '/' || *p == '\\') lastSlash = p;
    }
    if (lastSlash == NULL) return true; // current directory

    char dirPath[260];
    int len = (int)(lastSlash - filePath);
    if (len >= (int)sizeof(dirPath)) return false;
    std::strncpy(dirPath, filePath, len);
    dirPath[len] = '\0';
    MKDIR(dirPath); // one directory level (e.g. "data"); nested paths are Phase 3
    return true;
}

bool FileManager::loadExpenses(ExpenseManager& manager) {
    setLastError(NULL);
    m_loadedCount = 0;
    m_skippedCount = 0;

    std::ifstream inFile(m_filePath, std::ios::in);
    if (!inFile.is_open()) {
        char errBuf[512];
        std::snprintf(errBuf, sizeof(errBuf), "Could not open '%s' for reading", m_filePath);
        setLastError(errBuf);
        return false;
    }

    RecordParser parser;
    char lineBuffer[1024];
    while (inFile.getline(lineBuffer, sizeof(lineBuffer))) {
        // Strip Windows carriage return
        int len = (int)std::strlen(lineBuffer);
        if (len > 0 && lineBuffer[len - 1] == '\r') lineBuffer[--len] = '\0';

        // Blank lines are ignored (an empty file simply loads 0 records)
        bool isBlank = true;
        for (int i = 0; i < len; ++i) {
            if (lineBuffer[i] != ' ' && lineBuffer[i] != '\t') { isBlank = false; break; }
        }
        if (isBlank) continue;

        Expense parsed;
        if (!parser.parseRecord(lineBuffer, parsed)) { ++m_skippedCount; continue; }

        // addLoadedExpense keeps the saved ID and rejects duplicate IDs
        if (manager.addLoadedExpense(parsed)) ++m_loadedCount;
        else ++m_skippedCount;
    }
    inFile.close();

    if (m_skippedCount > 0) {
        char errBuf[512];
        std::snprintf(errBuf, sizeof(errBuf), "%d malformed/duplicate line(s) were skipped", m_skippedCount);
        setLastError(errBuf);
    }
    return true;
}

bool FileManager::saveExpenses(const ExpenseManager& manager) {
    setLastError(NULL);

    if (!ensureParentDirectoryExists(m_filePath)) {
        char errBuf[512];
        std::snprintf(errBuf, sizeof(errBuf), "Failed to create directory for '%s'", m_filePath);
        setLastError(errBuf);
        return false;
    }

    std::ofstream outFile(m_filePath, std::ios::out | std::ios::trunc);
    if (!outFile.is_open()) {
        char errBuf[512];
        std::snprintf(errBuf, sizeof(errBuf), "Could not open '%s' for writing", m_filePath);
        setLastError(errBuf);
        return false;
    }

    // The list keeps the newest record at the head. Write oldest -> newest so
    // that loading (insert-at-head) restores exactly the same on-screen order.
    int count = manager.getCount();
    if (count > 0) {
        Expense** items = new Expense*[count];
        int copied = manager.copyExpensePointers(items, count);
        for (int i = copied - 1; i >= 0; --i) {
            const Expense* e = items[i];
            outFile << e->getId() << '|' << e->getDate() << '|' << e->getAmountPaise() << '|'
                    << e->getMerchant() << '|' << e->getCategory() << '|'
                    << e->getExpenseType() << '|' << e->getFrequency() << '\n';
        }
        delete[] items;
    }

    outFile.flush();
    bool ok = outFile.good();
    outFile.close();
    if (!ok) {
        char errBuf[512];
        std::snprintf(errBuf, sizeof(errBuf), "Write error while saving '%s'", m_filePath);
        setLastError(errBuf);
    }
    return ok;
}
