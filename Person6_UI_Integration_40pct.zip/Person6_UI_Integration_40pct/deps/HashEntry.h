#ifndef HASH_ENTRY_H
#define HASH_ENTRY_H

/*
 * ============================================================================
 * MODULE: HashEntry (Person 3 - HashTable & LeakAnalyzer)
 * Description: Bounded storage cell for hash table containing grouping key,
 *              accumulated financial total in integer paise, transaction count,
 *              and spending statistics (min/max/average paise) for repeated
 *              spending detection.
 * Constraints: Strictly zero STL containers or algorithms.
 * ============================================================================
 */

#include <cstddef>

class HashEntry {
public:
  static const int MAX_KEY_LENGTH =
      128; // Bounded key length (including null terminator)

private:
  char m_key[MAX_KEY_LENGTH];
  long long m_totalPaise; // Total accumulated amount in integer paise
  int m_transactionCount; // Number of transactions recorded for this key
  bool m_occupied;        // True if this slot contains active data

public:
  // Constructors
  HashEntry();

  // Contract Interface
  bool setKey(const char *key);
  const char *getKey() const;
  long long getTotalPaise() const;
  int getTransactionCount() const;
  void addTransaction(long long amountPaise);

  // Inspection & State Management
  bool isOccupied() const;
  bool isEmpty() const;
  void clear();

  // PENDING (Phase 3): HashEntry(key, amount) ctor, getMinPaise(),
  //                    getMaxPaise(), getAveragePaise().
};

#endif // HASH_ENTRY_H
