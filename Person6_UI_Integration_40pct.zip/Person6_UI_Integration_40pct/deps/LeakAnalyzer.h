#ifndef LEAK_ANALYZER_H
#define LEAK_ANALYZER_H

/*
 * ============================================================================
 * MODULE: LeakAnalyzer (Person 3 - HashTable & LeakAnalyzer)  -- Phase 2 (40%)
 * Description: Spending leak detection using the custom HashTable. Groups
 *              expenses by "Category:Merchant" and by "Category", detects
 *              repeated spending patterns and prints a leak report.
 * Policy:
 *   1. High category totals are NOT automatically labelled wasteful.
 *   2. No forecasting / savings advice here (owned by Person 5).
 *   3. Reads expenses only through ExpenseManager::getHead(); never mutates
 *      records and never keeps a second master list.
 *   4. Zero STL containers or algorithms.
 *
 * PENDING (Phase 3): monthly (MM-YYYY) grouping table, analysis date span,
 *   min/max/average statistics per channel, HIGH-VOLUME category policy note,
 *   compliance section of the report, inspection getters.
 * ============================================================================
 */

#include "HashTable.h"
#include <iostream>

class ExpenseManager;

class LeakAnalyzer {
public:
  static const int MAX_PATTERNS = 256;
  static const int FREQUENT_SPENDING_THRESHOLD = 3; // >= 3 transactions
  static const int REPEATED_SPENDING_THRESHOLD = 2; // >= 2 transactions

private:
  HashTable m_table;         // Grouped spending by "Category:Merchant"
  HashTable m_categoryTable; // Spending totals grouped by "Category"

  const HashEntry *m_patterns[MAX_PATTERNS]; // Identified repeated patterns
  int m_patternCount;

  long long m_totalPaiseAnalyzed;
  int m_totalExpensesAnalyzed;

  static bool buildGroupKey(char *dest, int destSize, const char *category,
                            const char *merchant);
  bool isLeakPattern(const HashEntry *entry) const;

  LeakAnalyzer(const LeakAnalyzer &);            // not copyable
  LeakAnalyzer &operator=(const LeakAnalyzer &);

public:
  LeakAnalyzer();
  virtual ~LeakAnalyzer();

  bool analyzeExpenses(const ExpenseManager &manager);
  void displayLeakReport() const;
  void printLeakReport(std::ostream &os) const;

  int getPatternCount() const;
  const HashEntry *getPatternAt(int index) const;
  long long getTotalAnalyzedPaise() const;
  void clear();
};

#endif // LEAK_ANALYZER_H
