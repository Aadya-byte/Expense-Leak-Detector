#ifndef UNDO_ACTION_H
#define UNDO_ACTION_H

/*
 * UndoAction (Person 5) -- Phase 2 (40%)
 * Stores what is needed to reverse one supported expense operation.
 *   ADD    -> undo = delete the expense with this ID
 *   DELETE -> undo = restore the stored snapshot (original ID kept)
 * PENDING (Phase 3): EDIT actions (before/after snapshots).
 */

#include "Expense.h"

enum class ActionType {
    ADD,
    DELETE,
    UNKNOWN
};

class UndoAction {
private:
    ActionType type;
    long long expenseId;
    Expense beforeSnapshot;
    bool hasBefore;

public:
    UndoAction();
    UndoAction(ActionType t, long long id);

    ActionType getType() const;
    long long getExpenseId() const;

    bool getBeforeSnapshot(Expense& outExpense) const;
    void setBeforeSnapshot(const Expense& expense);
};

#endif // UNDO_ACTION_H
