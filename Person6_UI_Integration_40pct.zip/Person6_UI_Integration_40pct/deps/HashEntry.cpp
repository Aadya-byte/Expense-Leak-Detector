#include "HashEntry.h"

/*
 * ============================================================================
 * MODULE: HashEntry Implementation
 * Constraints: Strictly zero STL containers or algorithms.
 * ============================================================================
 */

HashEntry::HashEntry()
    : m_totalPaise(0),
      m_transactionCount(0),
      m_occupied(false) {
    m_key[0] = '\0';
}

bool HashEntry::setKey(const char* key) {
    if (key == NULL) {
        return false;
    }

    // Measure key length and validate bound
    int len = 0;
    while (key[len] != '\0') {
        len++;
        if (len >= MAX_KEY_LENGTH) {
            return false; // Key exceeds bounded array size
        }
    }

    if (len == 0) {
        return false; // Empty key rejected
    }

    // Safely copy key including null terminator
    for (int i = 0; i <= len; ++i) {
        m_key[i] = key[i];
    }

    return true;
}

const char* HashEntry::getKey() const {
    return m_key;
}

long long HashEntry::getTotalPaise() const {
    return m_totalPaise;
}

int HashEntry::getTransactionCount() const {
    return m_transactionCount;
}

void HashEntry::addTransaction(long long amountPaise) {
    // Validate numeric inputs (only positive amounts are allowed for expenses)
    if (amountPaise <= 0) {
        return;
    }

    // Guard against 64-bit integer overflow
    const long long MAX_PAISE = 0x7FFFFFFFFFFFFFFFLL;
    if (m_totalPaise > MAX_PAISE - amountPaise) {
        return;
    }

    m_totalPaise += amountPaise;
    m_transactionCount++;
    m_occupied = true;
}

bool HashEntry::isOccupied() const {
    return m_occupied;
}

bool HashEntry::isEmpty() const {
    return !m_occupied;
}

void HashEntry::clear() {
    m_key[0] = '\0';
    m_totalPaise = 0;
    m_transactionCount = 0;
    m_occupied = false;
}
