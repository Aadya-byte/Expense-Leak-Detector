#include "LeakAnalyzer.h"
#include "Expense.h"
#include "ExpenseManager.h"

/*
 * MODULE: LeakAnalyzer Implementation (Phase 2 / 40% scope)
 * Constraints: strictly zero STL containers or algorithms.
 */

LeakAnalyzer::LeakAnalyzer()
    : m_patternCount(0), m_totalPaiseAnalyzed(0), m_totalExpensesAnalyzed(0) {
  for (int i = 0; i < MAX_PATTERNS; ++i) m_patterns[i] = NULL;
}

LeakAnalyzer::~LeakAnalyzer() { clear(); }

void LeakAnalyzer::clear() {
  m_table.clear();
  m_categoryTable.clear();
  m_patternCount = 0;
  m_totalPaiseAnalyzed = 0;
  m_totalExpensesAnalyzed = 0;
  for (int i = 0; i < MAX_PATTERNS; ++i) m_patterns[i] = NULL;
}

bool LeakAnalyzer::buildGroupKey(char *dest, int destSize, const char *category,
                                 const char *merchant) {
  if (dest == NULL || category == NULL || merchant == NULL) return false;
  int catLen = 0, merLen = 0;
  while (category[catLen] != '\0') catLen++;
  while (merchant[merLen] != '\0') merLen++;
  if (catLen + 1 + merLen >= destSize) return false; // would overflow

  int idx = 0; // Format: "Category:Merchant"
  for (int i = 0; i < catLen; ++i) dest[idx++] = category[i];
  dest[idx++] = ':';
  for (int i = 0; i < merLen; ++i) dest[idx++] = merchant[i];
  dest[idx] = '\0';
  return true;
}

bool LeakAnalyzer::isLeakPattern(const HashEntry *entry) const {
  // Repeated spending at the same merchant/category (count >= 2)
  return entry != NULL && entry->isOccupied() &&
         entry->getTransactionCount() >= REPEATED_SPENDING_THRESHOLD;
}

bool LeakAnalyzer::analyzeExpenses(const ExpenseManager &manager) {
  clear();

  // Traverse the singly linked list; no records are modified or cloned.
  for (const ExpenseNode *n = manager.getHead(); n != NULL; n = n->getNext()) {
    const Expense &exp = n->getExpense();
    long long amount = exp.getAmountPaise();
    if (amount <= 0) continue;

    char groupKey[HashEntry::MAX_KEY_LENGTH];
    if (buildGroupKey(groupKey, sizeof(groupKey), exp.getCategory(), exp.getMerchant()))
      m_table.insertOrUpdate(groupKey, amount);        // Category:Merchant
    m_categoryTable.insertOrUpdate(exp.getCategory(), amount); // Category totals

    m_totalPaiseAnalyzed += amount;
    m_totalExpensesAnalyzed++;
  }

  for (int i = 0; i < m_table.getCapacity(); ++i) {
    const HashEntry *entry = m_table.getEntryAt(i);
    if (isLeakPattern(entry) && m_patternCount < MAX_PATTERNS)
      m_patterns[m_patternCount++] = entry;
  }
  return true;
}

int LeakAnalyzer::getPatternCount() const { return m_patternCount; }

const HashEntry *LeakAnalyzer::getPatternAt(int index) const {
  return (index < 0 || index >= m_patternCount) ? NULL : m_patterns[index];
}

long long LeakAnalyzer::getTotalAnalyzedPaise() const { return m_totalPaiseAnalyzed; }

static void printMoney(std::ostream &os, long long paise) {
  os << "Rs. " << paise / 100 << "." << (paise % 100 < 10 ? "0" : "") << paise % 100;
}

void LeakAnalyzer::displayLeakReport() const { printLeakReport(std::cout); }

void LeakAnalyzer::printLeakReport(std::ostream &os) const {
  os << "=========== SPENDING LEAK REPORT ===========\n";
  os << "Expenses analyzed : " << m_totalExpensesAnalyzed << "\n";
  os << "Total spending    : ";
  printMoney(os, m_totalPaiseAnalyzed);
  os << "\nRepeated patterns : " << m_patternCount << "\n";

  os << "--- Repeated spending (Category:Merchant) ---\n";
  if (m_patternCount == 0) os << "  None detected.\n";
  for (int i = 0; i < m_patternCount; ++i) {
    const HashEntry *e = m_patterns[i];
    os << "  [" << e->getKey() << "] " << e->getTransactionCount() << " transactions, total ";
    printMoney(os, e->getTotalPaise());
    os << (e->getTransactionCount() >= FREQUENT_SPENDING_THRESHOLD ? "  -> FREQUENT SPENDING"
                                                                   : "  -> REPEATED")
       << " (possible saving, not assumed unnecessary)\n";
  }

  os << "--- Category totals ---\n";
  if (m_categoryTable.getEntryCount() == 0) os << "  No data.\n";
  for (int i = 0; i < m_categoryTable.getCapacity(); ++i) {
    const HashEntry *c = m_categoryTable.getEntryAt(i);
    if (c != NULL && c->isOccupied()) {
      os << "  " << c->getKey() << " : ";
      printMoney(os, c->getTotalPaise());
      os << " (" << c->getTransactionCount() << " transaction(s))\n";
    }
  }
  os << "============================================\n";
}
