/*
 * ============================================================================
 * RECORD PARSER MODULE IMPLEMENTATION
 * File: RecordParser.cpp
 * Owned by: Person 2 (Persistence & Export Module)
 * ============================================================================
 */

#include "RecordParser.h"
#include "Expense.h"
#include <cstring>
#include <cctype>
#include <cstdlib>

RecordParser::RecordParser() {
}

RecordParser::~RecordParser() {
}

void RecordParser::trimWhitespace(char* str) {
    if (str == NULL) return;
    int len = (int)std::strlen(str);
    if (len == 0) return;

    // Trim trailing whitespace and carriage returns/newlines
    int end = len - 1;
    while (end >= 0 && (str[end] == ' ' || str[end] == '\t' || str[end] == '\r' || str[end] == '\n')) {
        str[end] = '\0';
        end--;
    }

    // Trim leading whitespace
    int start = 0;
    while (str[start] != '\0' && (str[start] == ' ' || str[start] == '\t' || str[start] == '\r' || str[start] == '\n')) {
        start++;
    }

    if (start > 0) {
        int i = 0;
        while (str[start] != '\0') {
            str[i++] = str[start++];
        }
        str[i] = '\0';
    }
}

bool RecordParser::isAllWhitespace(const char* str) {
    if (str == NULL) return true;
    while (*str) {
        if (!std::isspace((unsigned char)*str)) {
            return false;
        }
        str++;
    }
    return true;
}

static void toUpperInPlace(char* s) {
    for (; *s; ++s) {
        if (*s >= 'a' && *s <= 'z') *s = (char)(*s - 'a' + 'A');
    }
}

bool RecordParser::parsePositiveInt(const char* str, int& outVal) const {
    if (str == NULL || *str == '\0') return false;
    int len = (int)std::strlen(str);
    if (len > 9) return false; // Prevent overflow beyond standard int

    for (int i = 0; i < len; ++i) {
        if (!std::isdigit((unsigned char)str[i])) return false;
    }

    long val = std::atol(str);
    if (val <= 0 || val > 2147483647L) return false;

    outVal = (int)val;
    return true;
}

bool RecordParser::parseAmount(const char* amountStr, long long& outPaise) const {
    if (amountStr == NULL || *amountStr == '\0') return false;

    // Integer paise representation only (e.g. "15000" for Rs 150.00).
    // PENDING (Phase 3): decimal-rupee input such as "150.50".
    int len = (int)std::strlen(amountStr);
    if (len == 0 || len > 15) return false;
    long long val = 0;
    for (int i = 0; i < len; ++i) {
        if (!std::isdigit((unsigned char)amountStr[i])) return false;
        val = val * 10 + (amountStr[i] - '0');
    }
    if (val <= 0) return false;
    outPaise = val;
    return true;
}

bool RecordParser::isValidType(const char* typeStr) const {
    if (typeStr == NULL || *typeStr == '\0') return false;
    return std::strcmp(typeStr, "ONE_TIME") == 0 || std::strcmp(typeStr, "RECURRING") == 0;
}

bool RecordParser::isValidFrequency(const char* freqStr, const char* typeStr) const {
    if (freqStr == NULL || typeStr == NULL) return false;
    if (std::strcmp(typeStr, "ONE_TIME") == 0) {
        return std::strcmp(freqStr, "NONE") == 0;
    }
    if (std::strcmp(typeStr, "RECURRING") == 0) {
        return std::strcmp(freqStr, "DAILY") == 0 ||
               std::strcmp(freqStr, "WEEKLY") == 0 ||
               std::strcmp(freqStr, "MONTHLY") == 0;
    }
    return false;
}

bool RecordParser::validateRecord(const Expense& expense) const {
    // 1. ID must be positive
    if (expense.getId() <= 0) return false;

    // 2. Date is checked (DD-MM-YYYY, real calendar date) by Expense::isValid() below.
    //    PENDING (Phase 3): independent calendar validation inside the parser.

    // 3. Amount must be positive integer paise
    if (expense.getAmountPaise() <= 0) return false;

    // 4. Merchant: non-empty, within length, no '|'
    const char* merchant = expense.getMerchant();
    if (merchant == NULL || *merchant == '\0') return false;
    if (std::strlen(merchant) > 50) return false;
    if (std::strchr(merchant, '|') != NULL) return false;
    if (isAllWhitespace(merchant)) return false;

    // 5. Category: non-empty, within length, no '|'
    const char* category = expense.getCategory();
    if (category == NULL || *category == '\0') return false;
    if (std::strlen(category) > 30) return false;
    if (std::strchr(category, '|') != NULL) return false;
    if (isAllWhitespace(category)) return false;

    // 6. Type: valid enum / string
    const char* typeStr = expense.getExpenseType();
    if (!isValidType(typeStr)) return false;

    // 7. Frequency: valid and compatible with Type
    const char* freqStr = expense.getFrequency();
    if (!isValidFrequency(freqStr, typeStr)) return false;

    // 8. Final object-level validation (date, lengths, type/frequency)
    return expense.isValid();
}

bool RecordParser::parseRecord(const char* line, Expense& outputExpense) const {
    if (line == NULL) return false;

    // Count pipes: exactly 6 pipes needed for 7 fields
    int pipeCount = 0;
    const char* ptr = line;
    while (*ptr != '\0') {
        if (*ptr == '\r' || *ptr == '\n') break;
        if (*ptr == '|') pipeCount++;
        ptr++;
    }
    if (pipeCount != 6) {
        return false;
    }

    // Extract 7 fields into fixed-size character buffers (No STL)
    char fields[7][128];
    int currentField = 0;
    int fieldCharIdx = 0;
    ptr = line;

    while (*ptr != '\0' && *ptr != '\r' && *ptr != '\n') {
        if (*ptr == '|') {
            fields[currentField][fieldCharIdx] = '\0';
            currentField++;
            fieldCharIdx = 0;
            if (currentField > 6) return false;
        } else {
            if (fieldCharIdx >= 127) {
                // Field length exceeds maximum permissible buffer
                return false;
            }
            fields[currentField][fieldCharIdx++] = *ptr;
        }
        ptr++;
    }
    fields[currentField][fieldCharIdx] = '\0';

    if (currentField != 6) {
        return false;
    }

    // Trim whitespace from each field
    for (int i = 0; i < 7; ++i) {
        trimWhitespace(fields[i]);
    }

    // Field 1: ID (Numeric positive integer)
    int id = 0;
    if (!parsePositiveInt(fields[0], id)) {
        return false;
    }

    // Field 2: Date - format/calendar validity is enforced by Expense::isValid()

    // Field 3: Amount (integer paise, positive)
    long long amountPaise = 0;
    if (!parseAmount(fields[2], amountPaise)) {
        return false;
    }

    // Field 4: Merchant (1-63 chars, no '|', not all whitespace)
    if (fields[3][0] == '\0' || isAllWhitespace(fields[3]) || std::strlen(fields[3]) > 50) {
        return false;
    }
    if (std::strchr(fields[3], '|') != NULL) {
        return false;
    }

    // Field 5: Category (1-63 chars, no '|', not all whitespace)
    if (fields[4][0] == '\0' || isAllWhitespace(fields[4]) || std::strlen(fields[4]) > 30) {
        return false;
    }
    if (std::strchr(fields[4], '|') != NULL) {
        return false;
    }

    // Field 6: Type (ONE_TIME or RECURRING) - normalised to upper case
    toUpperInPlace(fields[5]);
    toUpperInPlace(fields[6]);
    if (!isValidType(fields[5])) {
        return false;
    }

    // Field 7: Frequency (Consistent with Type)
    if (!isValidFrequency(fields[6], fields[5])) {
        return false;
    }

    // Build the Person 1 Expense object and run object-level validation
    Expense candidate(id, fields[1], amountPaise, fields[3], fields[4], fields[5], fields[6]);
    if (!validateRecord(candidate)) return false;
    outputExpense = candidate;
    return true;
}
