#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

/*
 * ============================================================================
 * FILE MANAGER MODULE (Person 2) -- Phase 2 (40%)
 * - Loads / saves expenses in the agreed pipe-delimited format:
 *       ID|DD-MM-YYYY|amountPaise|Merchant|Category|ONE_TIME/RECURRING|FREQ
 * - Preserves saved IDs through ExpenseManager::addLoadedExpense().
 * - Handles missing / empty files safely; malformed lines are skipped and
 *   counted (the program never crashes on a bad file).
 * - Saves in a stable order so that save -> load -> save keeps the order.
 * - Zero STL containers.
 *
 * PENDING (Phase 3): two-pass transactional load with exact line-number
 *   errors, duplicate-ID report, atomic temp-file snapshot save,
 *   ReportExporter (monthly report export).
 * ============================================================================
 */

class ExpenseManager;

class FileManager {
public:
  FileManager(const char *filePath = "data/expenses.txt");
  ~FileManager();

  // Load records into an (empty) manager. Returns false if the file cannot be
  // opened (e.g. first run); getLastError() explains why.
  bool loadExpenses(ExpenseManager &manager);

  // Save all records from the manager to the data file.
  bool saveExpenses(const ExpenseManager &manager);

  const char *getLastError() const;
  const char *getFilePath() const;
  void setFilePath(const char *filePath);
  int getLoadedCount() const;  // records accepted by the last load
  int getSkippedCount() const; // malformed/duplicate lines skipped by last load

private:
  char m_filePath[260];
  char m_lastError[512];
  int m_loadedCount;
  int m_skippedCount;

  void setLastError(const char *error);
  static bool ensureParentDirectoryExists(const char *filePath);
};

#endif // FILE_MANAGER_H
