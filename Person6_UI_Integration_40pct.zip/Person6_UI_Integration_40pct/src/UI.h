#ifndef UI_H
#define UI_H

/*
 * UI (Person 6) -- Phase 2 (40%): menu-driven console interface that connects
 * the modules finished so far. Items marked PENDING print a clear notice.
 */

#include "ExpenseManager.h"
#include "LeakAnalyzer.h"
#include "Search.h"
#include "Sort.h"
#include "UndoStack.h"

class UI {
private:
    ExpenseManager& manager;
    LeakAnalyzer& leakAnalyzer;
    Search& search;
    Sort& sort;
    UndoStack& undoStack;

    bool readInt(const char* prompt, int& value) const;
    bool readPositiveAmount(const char* prompt, long long& value) const;
    bool readText(const char* prompt, char* buffer, int capacity) const;
    void addExpense();
    void viewExpenses() const;
    void deleteExpense();
    void searchExpense();
    void sortExpenses();
    void showLeakReport();
    void undoLast();
    void showPending(const char* feature, const char* owner) const;

public:
    UI(ExpenseManager& manager, LeakAnalyzer& leakAnalyzer, Search& search,
       Sort& sort, UndoStack& undoStack);

    void run();
    void displayMainMenu() const;
};

#endif
