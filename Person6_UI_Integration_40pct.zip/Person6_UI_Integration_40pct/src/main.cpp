/*
 * Application entry point (Person 6) -- Phase 2 (40%).
 * Flow: load saved expenses -> run menu UI -> save on exit.
 */
#include <iostream>
#include "ExpenseManager.h"
#include "FileManager.h"
#include "LeakAnalyzer.h"
#include "Search.h"
#include "Sort.h"
#include "UndoStack.h"
#include "UI.h"

int main() {
    ExpenseManager manager;
    FileManager fileManager("data/expenses.txt");

    if (fileManager.loadExpenses(manager)) {
        std::cout << "Loaded " << fileManager.getLoadedCount() << " saved expense(s) from "
                  << fileManager.getFilePath() << ".\n";
        if (fileManager.getSkippedCount() > 0)
            std::cout << "Warning: " << fileManager.getLastError() << ".\n";
    } else {
        std::cout << "No saved data found (" << fileManager.getLastError()
                  << "). Starting with an empty list.\n";
    }

    LeakAnalyzer leakAnalyzer;
    Search search;
    Sort sort;
    UndoStack undoStack;

    UI ui(manager, leakAnalyzer, search, sort, undoStack);
    ui.run();

    if (fileManager.saveExpenses(manager))
        std::cout << "Saved " << manager.getCount() << " expense(s) to "
                  << fileManager.getFilePath() << ". Goodbye!\n";
    else
        std::cout << "ERROR: could not save data: " << fileManager.getLastError() << "\n";
    return 0;
}
