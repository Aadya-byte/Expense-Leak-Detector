#include "UI.h"
#include "Expense.h"
#include "UndoAction.h"
#include <iostream>
#include <limits>
#include <new>

UI::UI(ExpenseManager& m, LeakAnalyzer& la, Search& s, Sort& so, UndoStack& us)
    : manager(m), leakAnalyzer(la), search(s), sort(so), undoStack(us) {}

bool UI::readInt(const char* prompt, int& value) const {
    std::cout << prompt;
    if (std::cin >> value) return true;
    if (std::cin.eof()) return false;
    std::cin.clear();
    std::cin.ignore((std::numeric_limits<std::streamsize>::max)(), '\n');
    std::cout << "Invalid input. Please enter a whole number.\n";
    return false;
}

bool UI::readPositiveAmount(const char* prompt, long long& value) const {
    std::cout << prompt;
    if (!(std::cin >> value) || value <= 0) {
        if (std::cin.eof()) return false;
        std::cin.clear();
        std::cin.ignore((std::numeric_limits<std::streamsize>::max)(), '\n');
        std::cout << "Amount must be a positive whole number of paise.\n";
        return false;
    }
    return true;
}

bool UI::readText(const char* prompt, char* buffer, int capacity) const {
    if (!buffer || capacity < 2) return false;
    std::cout << prompt;
    std::cin >> std::ws;
    std::cin.getline(buffer, capacity);
    if (std::cin.eof() && buffer[0] == '\0') return false;
    if (std::cin.fail()) {
        std::cin.clear();
        std::cin.ignore((std::numeric_limits<std::streamsize>::max)(), '\n');
        std::cout << "Input too long. Please try again with a shorter value.\n";
        return false;
    }
    if (buffer[0] == '\0') {
        std::cout << "Input cannot be empty.\n";
        return false;
    }
    return true;
}

void UI::displayMainMenu() const {
    std::cout << "\n========== EXPENSE LEAK DETECTOR ==========\n"
              << " 1. Add expense\n"
              << " 2. View all expenses\n"
              << " 3. Edit expense                 [PENDING - Phase 3]\n"
              << " 4. Delete expense\n"
              << " 5. Search expense by ID\n"
              << " 6. Sort expenses (ID / amount / date)\n"
              << " 7. View spending leak report\n"
              << " 8. Forecast and savings         [PENDING - Phase 3]\n"
              << " 9. Undo last add / delete\n"
              << "10. Export monthly report        [PENDING - Phase 3]\n"
              << "11. Save and exit\n"
              << "===========================================\n";
}

void UI::showPending(const char* feature, const char* owner) const {
    std::cout << feature << " is pending (" << owner << ", Phase 3). "
              << "Not part of the 40% delivered so far.\n";
}

void UI::addExpense() {
    char date[16], merchant[64], category[40], type[20], frequency[20];
    long long amount;
    int id = 0;
    if (!readText("Date (DD-MM-YYYY): ", date, sizeof(date)) ||
        !readPositiveAmount("Amount in paise (e.g. 12550 = Rs.125.50): ", amount) ||
        !readText("Merchant: ", merchant, sizeof(merchant)) ||
        !readText("Category: ", category, sizeof(category)) ||
        !readText("Type (ONE_TIME/RECURRING): ", type, sizeof(type)) ||
        !readText("Frequency (NONE/DAILY/WEEKLY/MONTHLY): ", frequency, sizeof(frequency)))
        return;

    if (!manager.addExpense(date, amount, merchant, category, type, frequency, id)) {
        std::cout << "Error: expense was not added. Check date, amount, field lengths and "
                     "type/frequency combination (ONE_TIME needs NONE).\n";
        return;
    }
    undoStack.push(UndoAction(ActionType::ADD, id)); // undo history is bounded (100)
    std::cout << "Expense added successfully. Assigned ID: " << id << "\n";
}

void UI::viewExpenses() const {
    manager.displayExpenses();
}

void UI::deleteExpense() {
    int id;
    if (!readInt("Enter expense ID to delete: ", id)) return;
    const Expense* found = manager.findExpenseById(id);
    if (!found) { std::cout << "No expense found with that ID.\n"; return; }
    UndoAction action(ActionType::DELETE, id);
    action.setBeforeSnapshot(*found); // copy taken before the node is freed
    if (manager.deleteExpense(id)) {
        undoStack.push(action);
        std::cout << "Expense deleted successfully.\n";
    } else std::cout << "Delete failed.\n";
}

void UI::searchExpense() {
    int id, method;
    if (!readInt("Enter expense ID to search: ", id) ||
        !readInt("Method: 1=Linear search, 2=Binary search : ", method)) return;
    int count = manager.getCount();
    if (count <= 0) { std::cout << "No expenses to search.\n"; return; }
    Expense** items = new (std::nothrow) Expense*[count];
    if (!items) { std::cout << "Not enough memory to search.\n"; return; }
    int copied = manager.copyExpensePointers(items, count);
    Expense* result = 0;
    if (copied >= 0 && method == 1) result = search.linearSearchById(items, copied, id);
    else if (copied >= 0 && method == 2) {
        sort.sortById(items, copied); // binary search needs sorted data
        result = search.binarySearchById(items, copied, id);
    }
    if (result) { std::cout << "Found: "; result->display(); }
    else std::cout << "No expense found with that ID (or invalid method).\n";
    delete[] items; // only the pointer array is owned here, not the records
}

void UI::sortExpenses() {
    int choice;
    if (!readInt("Sort by: 1=ID, 2=Amount, 3=Date : ", choice)) return;
    int count = manager.getCount();
    if (count <= 0) { std::cout << "No expenses to sort.\n"; return; }
    if (choice < 1 || choice > 3) { std::cout << "Invalid sort choice.\n"; return; }
    Expense** items = new (std::nothrow) Expense*[count];
    if (!items) { std::cout << "Not enough memory to sort.\n"; return; }
    int copied = manager.copyExpensePointers(items, count);
    if (choice == 1) sort.sortById(items, copied);
    else if (choice == 2) sort.sortByAmount(items, copied);
    else sort.sortByDate(items, copied);
    for (int i = 0; i < copied; ++i) items[i]->display();
    delete[] items;
}

void UI::showLeakReport() {
    if (leakAnalyzer.analyzeExpenses(manager)) leakAnalyzer.displayLeakReport();
    else std::cout << "Leak analysis failed.\n";
}

void UI::undoLast() {
    UndoAction action;
    if (!undoStack.pop(action)) { std::cout << "Nothing to undo.\n"; return; }
    const int id = static_cast<int>(action.getExpenseId());
    bool ok = false;
    if (action.getType() == ActionType::ADD) {
        ok = manager.deleteExpense(id);
    } else if (action.getType() == ActionType::DELETE) {
        Expense before;
        if (action.getBeforeSnapshot(before)) ok = manager.addLoadedExpense(before);
    }
    if (ok) std::cout << "Undo completed.\n";
    else std::cout << "Undo failed for this action.\n";
}

void UI::run() {
    bool running = true;
    while (running) {
        displayMainMenu();
        int choice;
        if (!readInt("Select an option (1-11): ", choice)) {
            if (std::cin.eof()) break; // input closed: leave the loop safely
            continue;
        }
        switch (choice) {
            case 1: addExpense(); break;
            case 2: viewExpenses(); break;
            case 3: showPending("Edit expense", "Person 1"); break;
            case 4: deleteExpense(); break;
            case 5: searchExpense(); break;
            case 6: sortExpenses(); break;
            case 7: showLeakReport(); break;
            case 8: showPending("Forecast and savings advisor", "Person 5"); break;
            case 9: undoLast(); break;
            case 10: showPending("Monthly report export", "Person 2"); break;
            case 11: running = false; break;
            default: std::cout << "Choose a number from 1 to 11.\n"; break;
        }
    }
}
